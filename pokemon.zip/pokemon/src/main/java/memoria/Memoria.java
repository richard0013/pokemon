
package memoria;


public class Memoria {

    
    public static void main(String[] args) {
        Batalla obj = new Batalla();
      
    }
    
}
