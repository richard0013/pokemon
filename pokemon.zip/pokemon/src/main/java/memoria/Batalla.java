
package memoria;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;


public class Batalla {
    
    //atributos
    JFrame ventana;
    //presentacion
    JLabel fondoPresentacion;
    JLabel BotonJugar;
    JPanel panelPresentacion;
    //juego
    JPanel panelJuego;
    JLabel fondoJuego;
    JLabel matriz[][];
    int mat[][];
    int matAux[][];
    String jugador;
    Random aleatorio; 
    JLabel nombreJugador;
    int contador;
    //int filas=8;
    //int columnas=5;
           
    
    //constructor
    public Batalla(){
    
        ventana = new JFrame ("Batalla POKEMON");
        ventana.setSize(1080,700);
        ventana.setLayout(null);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
        
        //Jpanel presentacion
        panelPresentacion = new JPanel ();
        panelPresentacion.setSize(ventana.getWidth(), ventana.getHeight());
        panelPresentacion.setLocation(0,0);
        panelPresentacion.setLayout(null);
        panelPresentacion.setVisible(true);
               
        //fondo de batallas
        
        fondoPresentacion = new JLabel();
        fondoPresentacion.setSize(ventana.getWidth(), ventana.getHeight());
        fondoPresentacion.setLocation(0,0);
        fondoPresentacion.setIcon(new ImageIcon("poke/fondoprincipal.jpg"));
        fondoPresentacion.setVisible(true);
        panelPresentacion.add(fondoPresentacion,0);
       
        //boton jugar
        
        BotonJugar = new JLabel();
        BotonJugar.setSize(800,800);
        BotonJugar.setLocation(225,0);
        BotonJugar.setIcon(new ImageIcon("poke/BotonJugar.png"));
        BotonJugar.setVisible(true);
        panelPresentacion.add(BotonJugar,0);
        
        //Jpanel juego
        panelJuego = new JPanel ();
        panelJuego.setSize(ventana.getWidth(), ventana.getHeight());
        panelJuego.setLocation(0,0);
        panelJuego.setLayout(null);
        panelJuego.setVisible(true);
        
        //fondo de juego
        fondoJuego = new JLabel ();
        fondoJuego.setSize(ventana.getWidth(), ventana.getHeight());
        fondoJuego.setLocation(0,0);
        fondoJuego.setIcon(new ImageIcon("poke/fondo.png"));
        fondoJuego.setVisible(true);
        panelJuego.add(fondoJuego,0);

        //nombre del jugador
        
        nombreJugador = new JLabel ();
        nombreJugador.setSize(150, 20);
        nombreJugador.setLocation(500,5);
        nombreJugador.setForeground(Color.YELLOW);
        nombreJugador.setVisible(true);
        panelJuego.add(nombreJugador,0);
        
        //matriz logica
        mat= new int [8][5];
        matAux= new int[8][5];
        aleatorio = new Random();
        this.numerosAleatorios();
  
         
        //matriz imagenes
        
        matriz = new JLabel[8][5];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 5; j++) {
                matriz [i][j] = new JLabel();
                matriz[i][j].setBounds(50+(i*125),20+(j*125),125,125);
                matriz[i][j].setIcon(new ImageIcon("poke/"+ matAux[i][j]+".png"));
                matriz[i][j].setVisible(true);
                panelJuego.add(matriz[i][j],0);
            }
            
        }
        //tiempo espera
        // click cartas voltear
        
        contador = 0;
        
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 5; j++) {
                matriz[i][j].addMouseListener(new MouseAdapter(){
                    @Override
                    public void mousePressed(MouseEvent e){
                        for (int k = 0; k < 8; k++) {
                            for (int l = 0; l < 5; l++) {
                                if(e.getSource()== matriz[k][l]){
                                    //System.out.println(k+" "+l);
                                    if (matAux[k][l]==0) {
                                        matAux[k][l]= mat[k][l];
                                        matriz[k][l].setIcon(new ImageIcon("poke/"+ matAux[k][l]+".png"));
                                        contador++;
                                        if(contador==2){
                                            for (int m = 0; m < 8; m++) {
                                                for (int n = 0; n < 5; n++) {
                                                    if(matAux[m][n] != 0 && matAux[m][n]!=-1){
                                                        matAux[m][n]= 0;
                                                        matriz[m][n].setIcon(new ImageIcon("poke/"+ matAux[m][n]+".png"));
                                                        contador=0;
                                                    
                                                    }
                                                    
                                                }
                                            }
                                        }
                                    }
                                    
                                    
                                
                                
                                }
                                
                            }
 
                        }
                    
                    }
                }); 
                        
                
            }
            
        }
        
        
        
        
        
        BotonJugar.addMouseListener ( new MouseAdapter()  {
           
            @Override
            public void mousePressed(MouseEvent e){
            //System.out.println("Presione el boton");
            
            jugador = JOptionPane.showInputDialog(ventana, "Nombre del jugador", "Escribe aqui");
            while (jugador == null || jugador.compareTo("Escribe aqui")==0 || jugador.compareTo("")==0){
                    jugador = JOptionPane.showInputDialog(ventana, "Debes ingresar usuario", "Escribe aqui");
                    }
            nombreJugador.setText("Jugador: "+ jugador);
            panelPresentacion.setVisible(false);
            ventana.add(panelJuego);
            panelJuego.setVisible(true);
            }

            private int compareTo(String string) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
            
      }); 
                
                
    
        ventana.add(panelPresentacion); 
        ventana.setVisible(true);
    }
    
    public void numerosAleatorios(){
        int acumulador = 0;  
        for (int i = 0; i < 8; i++) 
            for (int j = 0; j < 5; j++){
                mat[i][j]=0;
                matAux[i][j] =0;
            }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 5 ; j++) {
                mat[i][j]=aleatorio.nextInt(20)+1;
                do{
                    acumulador =0;
                for (int k = 0; k < 8; k++) {
                    for (int l = 0; l < 5; l++) {
                        if (mat[i][j]==mat [k][l] ){
                            acumulador +=1;
                            }   
                        }    
                    }
                     if(acumulador== 3){
                        mat[i][j] = aleatorio.nextInt(20)+1;
                
                    }
                    
                }while (acumulador == 3);   
            }   
        }  
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 5; j++) {
                        System.out.print(mat[i][j]+ "  ");
                    }
                    System.out.println("");
                }
    
    }

}
